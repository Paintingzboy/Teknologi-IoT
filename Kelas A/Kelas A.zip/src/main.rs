use anyhow::{anyhow, Result};
use esp_idf_svc::eventloop::EspSystemEventLoop;
use esp_idf_svc::hal::peripherals::Peripherals;
use esp_idf_svc::nvs::EspDefaultNvsPartition;
use esp_idf_svc::wifi::{AuthMethod, BlockingWifi, ClientConfiguration, Configuration, EspWifi};
use log::*;
use serde::Serialize;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::thread;
use std::time::Duration;

// --- Wi-Fi configuration ---
const WIFI_SSID: &str = "TeknologiIoT";
const WIFI_PASS: &str = "passwordwifi";

// --- Backend / database service ---
const BACKEND_HOST: &str = "192.168.1.50";
const BACKEND_PORT: u16 = 8080;
const BACKEND_PATH: &str = "/api/sensor";

#[derive(Serialize)]
struct SensorPayload {
    temperature: f32,
    humidity: f32,
    air_quality: u16,
    device_id: &'static str,
}

fn main() -> Result<()> {
    esp_idf_svc::sys::link_patches();
    esp_idf_svc::log::EspLogger::initialize_default();

    info!("ESP32-S3 sensor sender started");

    let wifi_thread = std::thread::Builder::new()
        .stack_size(128 * 1024)
        .spawn(move || -> Result<()> {
            let peripherals = Peripherals::take()?;
            let sys_loop = EspSystemEventLoop::take()?;
            let nvs = EspDefaultNvsPartition::take()?;

            info!("Connecting to Wi-Fi SSID: {}", WIFI_SSID);
            let mut wifi = BlockingWifi::wrap(
                EspWifi::new(peripherals.modem, sys_loop.clone(), Some(nvs))?,
                sys_loop,
            )?;

            wifi.set_configuration(&Configuration::Client(ClientConfiguration {
                ssid: WIFI_SSID.try_into().map_err(|_| anyhow!("SSID too long"))?,
                password: WIFI_PASS.try_into().map_err(|_| anyhow!("Password too long"))?,
                auth_method: AuthMethod::WPA2Personal,
                ..Default::default()
            }))?;

            wifi.start()?;
            wifi.connect()?;
            wifi.wait_netif_up()?;
            info!("Wi-Fi connected successfully!");

            let mut counter = 0u64;
            loop {
                counter += 1;

                let sensor = SensorPayload {
                    temperature: read_dht22_temperature(),
                    humidity: read_dht22_humidity(),
                    air_quality: read_mq135(),
                    device_id: "esp32s3_a",
                };

                let json = serde_json::to_string(&sensor)?;

                info!(
                    "[{}] Temperature: {:.1} C | Humidity: {:.1} % | AirQuality: {} ppm",
                    counter,
                    sensor.temperature,
                    sensor.humidity,
                    sensor.air_quality
                );

                info!("Sending to backend: {}", json);
                if let Err(err) = send_http_post(&json) {
                    error!("Failed to send sensor data: {:?}", err);
                }

                thread::sleep(Duration::from_secs(5));
            }
        })?;

    match wifi_thread.join() {
        Ok(res) => res,
        Err(_) => Err(anyhow!("Wi-Fi worker thread panicked")),
    }
}

fn read_dht22_temperature() -> f32 {
    // Replace with actual DHT22 reading when hardware is connected.
    27.4
}

fn read_dht22_humidity() -> f32 {
    // Replace with actual DHT22 reading when hardware is connected.
    65.2
}

fn read_mq135() -> u16 {
    // Replace with actual ADC reading from MQ135 when connected.
    420
}

fn send_http_post(json: &str) -> Result<()> {
    let mut stream = TcpStream::connect((BACKEND_HOST, BACKEND_PORT))?;

    let request = format!(
        "POST {} HTTP/1.1\r\nHost: {}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
        BACKEND_PATH,
        BACKEND_HOST,
        json.len(),
        json
    );

    stream.write_all(request.as_bytes())?;
    stream.flush()?;

    let mut response = [0u8; 512];
    let _ = stream.read(&mut response)?;

    let response_text = String::from_utf8_lossy(&response);
    info!("Backend response: {}", response_text.trim());

    Ok(())
}
